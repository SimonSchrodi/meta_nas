def helper_function():
    print("I helped!")